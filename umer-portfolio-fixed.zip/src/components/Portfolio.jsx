import React, { useState } from 'react';
import {
  FaBars,
  FaTimes,
  FaGithub,
  FaLinkedin,
  FaEnvelope,
  FaPhone,
  FaMapMarkerAlt,
  FaExternalLinkAlt,
  FaDownload,
} from 'react-icons/fa';
import { HiArrowNarrowRight } from 'react-icons/hi';

const Portfolio = () => {
  const [nav, setNav] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  const scrollToSection = (sectionId) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
      setActiveSection(sectionId);
      setNav(false);
    }
  };

  const skills = [
    { name: 'Manual Testing', category: 'Testing', level: 90 },
    { name: 'API Testing', category: 'Testing', level: 85 },
    { name: 'Database Testing', category: 'Testing', level: 80 },
    { name: 'Selenium', category: 'Automation', level: 75 },
    { name: 'JIRA', category: 'Tools', level: 95 },
    { name: 'Postman', category: 'Tools', level: 90 },
    { name: 'Python', category: 'Programming', level: 70 },
    { name: 'SQL/MySQL', category: 'Database', level: 85 },
  ];

  const projects = [
    {
      id: 1,
      name: 'C-Holder',
      desc: 'Web and mobile application for card activity management',
      details:
        'Enables customers to view and manage their card activities, including transaction history, balance, debit, and credit amounts.',
      technologies: ['Manual Testing', 'API Testing', 'Mobile Testing', 'Database Testing'],
      type: 'Financial Application',
    },
    {
      id: 2,
      name: 'C-Manager/Admin',
      desc: 'Internal web application for card management',
      details:
        'Designed for generating client cards and configuring rules for various card types including credit, debit, and prepaid cards.',
      technologies: ['Web Testing', 'Functional Testing', 'UI Testing', 'Integration Testing'],
      type: 'Admin Dashboard',
    },
    {
      id: 3,
      name: 'C-Agent',
      desc: 'Customer support application',
      details:
        'Internal web application for Customer Support Representatives to verify, troubleshoot, and activate cards.',
      technologies: ['Manual Testing', 'UAT', 'Regression Testing', 'IVR Testing'],
      type: 'Support System',
    },
    {
      id: 4,
      name: 'Ecom FBA',
      desc: 'Amazon fulfillment system',
      details:
        'Amazon system for storing, picking, packing, shipping, and delivering products to customers.',
      technologies: ['E-commerce Testing', 'Integration Testing', 'Performance Testing'],
      type: 'E-commerce Platform',
    },
    {
      id: 5,
      name: 'QikFinds',
      desc: 'Product search extension',
      details:
        'Browser extension providing intelligence on sales and promotions from hundreds of online retailers.',
      technologies: ['Browser Testing', 'API Testing', 'Cross-platform Testing'],
      type: 'Browser Extension',
    },
    {
      id: 6,
      name: 'European Outdoor',
      desc: 'Employee management system',
      details:
        'Integrated system developed to facilitate user management for employees in outdoor industry.',
      technologies: ['System Testing', 'User Management Testing', 'Integration Testing'],
      type: 'Management System',
    },
  ];

  const experience = [
    {
      title: 'Quality Engineer',
      company: 'I2C INC',
      period: 'Feb 2024 - Present',
      achievements: [
        'Executed comprehensive test cases aligned with project requirements',
        'Conducted functional, integration, smoke, sanity, UI, regression, UAT and database testing',
        'Specialized in implementing client-specific solutions for credit, debit, and prepaid clients',
        'Performed IVR verification and testing',
        'Proficient in Linux environment including log analysis',
      ],
    },
    {
      title: 'Associate SQA Engineer',
      company: 'QBATCH',
      period: 'July 2022 - Jan 2024',
      achievements: [
        'Performed smoke, functional, and regression testing for web and mobile applications',
        'Designed and executed test cases using JIRA for issue tracking',
        'Conducted UI/UX testing across various devices and platforms',
        'Collaborated with development teams to resolve software defects efficiently',
      ],
    },
    {
      title: 'SQA Intern',
      company: 'DEVSINC',
      period: 'March 2022 - May 2022',
      achievements: [
        'Performed smoke, functional, and regression testing',
        'Conducted API Testing using Postman',
        'Performed Load and Stress Testing',
        'Gained hands-on experience in Manual Testing',
      ],
    },
  ];

  return (
    <div className="bg-gray-900 text-white min-h-screen">
      {/* ---------------- Navbar ---------------- */}
      <nav className="fixed w-full h-20 bg-gray-900/95 backdrop-blur-sm z-50 border-b border-gray-800">
        <div className="flex justify-between items-center w-full h-full px-4 max-w-7xl mx-auto">
          <div className="text-2xl font-bold text-cyan-400">Umer Owais</div>

          {/* Desktop Menu */}
          <ul className="hidden md:flex space-x-8">
            {['home', 'about', 'skills', 'experience', 'projects', 'contact'].map((item) => (
              <li key={item}>
                <button
                  onClick={() => scrollToSection(item)}
                  className={`capitalize hover:text-cyan-400 transition-colors duration-300 ${
                    activeSection === item ? 'text-cyan-400' : 'text-white'
                  }`}
                >
                  {item}
                </button>
              </li>
            ))}
          </ul>

          {/* Mobile Menu Button */}
          <div className="md:hidden z-10" onClick={() => setNav(!nav)}>
            {!nav ? <FaBars size={24} /> : <FaTimes size={24} />}
          </div>
        </div>

        {/* Mobile Menu */}
        <ul
          className={`${
            !nav ? 'hidden' : 'absolute'
          } top-0 left-0 w-full h-screen bg-gray-900 flex flex-col justify-center items-center space-y-8 md:hidden`}
        >
          {['home', 'about', 'skills', 'experience', 'projects', 'contact'].map((item) => (
            <li key={item}>
              <button
                onClick={() => scrollToSection(item)}
                className="text-4xl capitalize hover:text-cyan-400 transition-colors duration-300"
              >
                {item}
              </button>
            </li>
          ))}
        </ul>
      </nav>

      {/* ---------------- Hero ---------------- */}
      <section
        id="home"
        className="w-full h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900"
      >
        <div className="max-w-4xl mx-auto px-8 text-center">
          <p className="text-cyan-400 text-xl mb-4">Hi, my name is</p>
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-4">Muhammad Umer Owais</h1>
          <h2 className="text-4xl md:text-6xl font-bold text-gray-400 mb-6">SQA Engineer</h2>
          <p className="text-gray-300 text-lg max-w-2xl mx-auto mb-8">
            Dedicated and detail-oriented SQA Manual Engineer with 2.5 years of hands-on experience in
            delivering high-quality software solutions. Skilled in comprehensive manual testing processes
            to ensure software reliability and user satisfaction.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => scrollToSection('projects')}
              className="group bg-cyan-600 hover:bg-cyan-700 text-white px-8 py-3 rounded-lg transition-all duration-300 flex items-center justify-center"
            >
              View My Work
              <HiArrowNarrowRight className="ml-2 group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={() => scrollToSection('contact')}
              className="group border-2 border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-gray-900 px-8 py-3 rounded-lg transition-all duration-300 flex items-center justify-center"
            >
              Get In Touch
              <FaEnvelope className="ml-2 text-sm" />
            </button>
          </div>
        </div>
      </section>

      {/* ---------------- About ---------------- */}
      <section id="about" className="w-full py-20 bg-gray-800">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              About <span className="text-cyan-400">Me</span>
            </h2>
            <div className="w-24 h-1 bg-cyan-400 mx-auto" />
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-2xl font-bold text-white mb-6">Quality Assurance Professional</h3>
              <p className="text-gray-300 mb-6 leading-relaxed">
                I am passionate about ensuring software quality and reliability. With expertise in manual
                testing, API testing, and database testing, I specialize in delivering comprehensive QA
                solutions for clients ranging from small businesses to large enterprise corporations.
              </p>
              <p className="text-gray-300 mb-6 leading-relaxed">
                My experience spans across various domains including financial applications, e-commerce
                platforms, and customer support systems. I am committed to continuous learning and staying
                updated with industry trends to improve QA processes.
              </p>
              <div className="grid grid-cols-2 gap-4 text-center">
                <div className="bg-gray-700 p-4 rounded-lg">
                  <h4 className="text-2xl font-bold text-cyan-400">2.5+</h4>
                  <p className="text-gray-300">Years Experience</p>
                </div>
                <div className="bg-gray-700 p-4 rounded-lg">
                  <h4 className="text-2xl font-bold text-cyan-400">15+</h4>
                  <p className="text-gray-300">Projects Completed</p>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-gray-700 p-6 rounded-lg">
                <h4 className="text-xl font-bold text-cyan-400 mb-4">Education</h4>
                <p className="text-white font-semibold">BS Computer Science</p>
                <p className="text-gray-300">Khawaja Fareed University of Engineering and IT</p>
                <p className="text-gray-400">January 2017 - August 2021</p>
              </div>

              <div className="bg-gray-700 p-6 rounded-lg">
                <h4 className="text-xl font-bold text-cyan-400 mb-4">Location</h4>
                <div className="flex items-center text-gray-300">
                  <FaMapMarkerAlt className="mr-2 text-cyan-400" />
                  <span>Model Town, Lahore, Pakistan</span>
                </div>
              </div>

              <div className="bg-gray-700 p-6 rounded-lg">
                <h4 className="text-xl font-bold text-cyan-400 mb-4">Availability</h4>
                <p className="text-gray-300">Open to relocation opportunities worldwide</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ---------------- Skills ---------------- */}
      <section id="skills" className="w-full py-20 bg-gray-900">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Technical <span className="text-cyan-400">Skills</span>
            </h2>
            <div className="w-24 h-1 bg-cyan-400 mx-auto" />
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {skills.map((skill) => (
              <div key={skill.name} className="bg-gray-800 p-6 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-white font-semibold">{skill.name}</h3>
                  <span className="text-cyan-400 text-sm">{skill.category}</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-cyan-400 to-blue-500 h-2 rounded-full transition-all duration-1000"
                    style={{ width: `${skill.level}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------- Experience ---------------- */}
      <section id="experience" className="w-full py-20 bg-gray-800">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Work <span className="text-cyan-400">Experience</span>
            </h2>
            <div className="w-24 h-1 bg-cyan-400 mx-auto" />
          </div>

          <div className="space-y-8">
            {experience.map((exp) => (
              <div key={exp.title} className="bg-gray-900 p-8 rounded-lg border-l-4 border-cyan-400">
                <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-4">
                  <div>
                    <h3 className="text-2xl font-bold text-white">{exp.title}</h3>
                    <p className="text-cyan-400 text-lg font-semibold">{exp.company}</p>
                  </div>
                  <span className="text-gray-400 font-medium">{exp.period}</span>
                </div>
                <ul className="space-y-2">
                  {exp.achievements.map((ach) => (
                    <li key={ach} className="text-gray-300 flex items-start">
                      <span className="text-cyan-400 mr-2">•</span>
                      {ach}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------- Projects ---------------- */}
      <section id="projects" className="w-full py-20 bg-gray-900">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Featured <span className="text-cyan-400">Projects</span>
            </h2>
            <div className="w-24 h-1 bg-cyan-400 mx-auto" />
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project) => (
              <div
                key={project.id}
                className="bg-gray-800 rounded-lg overflow-hidden hover:transform hover:scale-105 transition-all duration-300"
              >
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-xl font-bold text-white">{project.name}</h3>
                    <span className="text-xs bg-cyan-600 text-white px-2 py-1 rounded">
                      {project.type}
                    </span>
                  </div>
                  <p className="text-gray-300 mb-4">{project.desc}</p>
                  <p className="text-gray-400 text-sm mb-4">{project.details}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.technologies.map((tech) => (
                      <span key={tech} className="text-xs bg-gray-700 text-cyan-400 px-2 py-1 rounded">
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------- Contact ---------------- */}
      <section id="contact" className="w-full py-20 bg-gray-800">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Get In <span className="text-cyan-400">Touch</span>
            </h2>
            <div className="w-24 h-1 bg-cyan-400 mx-auto" />
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-bold text-white mb-6">Let's Connect</h3>
              <p className="text-gray-300 mb-8">
                I'm always interested in new opportunities and collaborations. Feel free to reach out if you'd like
                to discuss QA projects or opportunities.
              </p>

              <div className="space-y-4">
                <div className="flex items-center">
                  <FaEnvelope className="text-cyan-400 mr-4" />
                  <span className="text-gray-300">umersoft07@gmail.com</span>
                </div>
                <div className="flex items-center">
                  <FaPhone className="text-cyan-400 mr-4" />
                  <span className="text-gray-300">+92 333 274 1803</span>
                </div>
                <div className="flex items-center">
                  <FaMapMarkerAlt className="text-cyan-400 mr-4" />
                  <span className="text-gray-300">Model Town, Lahore, Pakistan</span>
                </div>
              </div>

              <div className="flex space-x-4 mt-8">
                <a
                  href="https://www.linkedin.com/in/umer-owais"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-lg transition-colors duration-300"
                >
                  <FaLinkedin size={20} />
                </a>
                <a
                  href="mailto:umersoft07@gmail.com"
                  className="bg-gray-700 hover:bg-gray-600 text-white p-3 rounded-lg transition-colors duration-300"
                >
                  <FaEnvelope size={20} />
                </a>
              </div>
            </div>

            <div className="bg-gray-900 p-8 rounded-lg">
              <h3 className="text-2xl font-bold text-white mb-6">Send a Message</h3>
              <div className="space-y-4">
                <input
                  type="text"
                  placeholder="Your Name"
                  className="w-full bg-gray-800 text-white p-3 rounded-lg border border-gray-700 focus:border-cyan-400 focus:outline-none"
                />
                <input
                  type="email"
                  placeholder="Your Email"
                  className="w-full bg-gray-800 text-white p-3 rounded-lg border border-gray-700 focus:border-cyan-400 focus:outline-none"
                />
                <textarea
                  rows="6"
                  placeholder="Your Message"
                  className="w-full bg-gray-800 text-white p-3 rounded-lg border border-gray-700 focus:border-cyan-400 focus:outline-none resize-none"
                />
                <button
                  onClick={() => (window.location.href = 'mailto:umersoft07@gmail.com')}
                  className="w-full bg-cyan-600 hover:bg-cyan-700 text-white py-3 rounded-lg transition-colors duration-300"
                >
                  Send Message
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ---------------- Footer ---------------- */}
      <footer className="bg-gray-900 py-8 border-t border-gray-800">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <p className="text-gray-400">© 2024 Muhammad Umer Owais. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default Portfolio;
