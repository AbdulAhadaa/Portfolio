import React from "react";
import Portfolio from "./components/Portfolio";

function App() {
  return <Portfolio />;
}

export default App;
