# Umer Portfolio

A React + Tailwind CSS portfolio site.

## Getting Started

```bash
npm install
npm start
```
